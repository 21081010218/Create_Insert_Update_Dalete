<?php 

  include ('koneksi.php'); 

  $status = '';
  $result = '';
  //melakukan pengecekan apakah ada form yang dipost
  if ($_SERVER['REQUEST_METHOD'] === 'GET') {
      if (isset($_GET['productCode'])) {
          //query SQL
          $productCode = $_GET['productCode'];
          $sql = "DELETE FROM products WHERE productCode = '$productCode'"; 

          //eksekusi query
          $result = mysqli_query(connection(), $sql);

          if ($result) {
            $status = 'ok';
          }
          else{
            $status = 'err';
          }

          //redirect ke halaman lain
          header('Location: product.php?status='.$status);
      }  
  }
